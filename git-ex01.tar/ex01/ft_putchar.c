/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jsuarez- <jsuarez-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 09:26:17 by jsuarez-          #+#    #+#             */
/*   Updated: 2023/02/21 10:23:15 by jsuarez-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	ft_putchar( int row, int col, int len_x, int len_y)
{
	char	corner;
	char	line_h;
	char	line_v;
	char	line_s;

	corner = 'o';
	line_h = '-';
	line_v = '|';
	line_s = ' ';
	if ((row == 1 || row == len_y) && (col == 1 || col == len_x))
	{
		return (corner);
	}
	else if ((col > 1 || col < len_x) && (row == 1 || row == len_y))
	{
		return (line_h);
	}
	else if ((row > 1 || row < len_y) && (col == 1 || col == len_x))
	{
		return (line_v);
	}
	else
	{
		return (line_s);
	}
}
