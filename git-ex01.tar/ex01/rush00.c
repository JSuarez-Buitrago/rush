/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jsuarez- <jsuarez-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 08:58:13 by jsuarez-          #+#    #+#             */
/*   Updated: 2023/02/21 09:25:50 by jsuarez-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	ft_putchar(int row, int col, int len_x, int len_y);

void	rush(int x, int y)
{
	int		row;
	int		col;
	int		long;
	int		index;
	char	character[long];

	row = 1;
	col = 1;
	long = x*y+y;
	index = 0;
	while (row <= y)
{
	while( col <= x)
	{
    character[index] = ft_putchar(row,col,x,y);
        if(col == x)
		{
			++index;
        	character[index]='\n';
        }
			++col;
			++index;
    }
		col=1;
		++row;
}
	write(1,character,length);
}