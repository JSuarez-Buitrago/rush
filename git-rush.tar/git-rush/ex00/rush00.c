#include <unistd.h>
char ft_putchar(int row, int col, int len_x, int len_y);

void    rush(int x, int y)
{
    int     row=1;
    int     col=1;
    int     length= x*y + y;
    char    character[length];
    int     index=0;
    while(row<=y){
        while(col<=x){
            character[index]=ft_putchar(row,col,x,y);
            if(col==x){
                ++index;
                character[index]='\n';
            }
            ++col;
            ++index;
        }
        col=1;
        ++row;
    }
    write(1,character,length);
}