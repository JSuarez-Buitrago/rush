char ft_putchar(int row, int col, int len_x, int len_y){
    char    corner = 'o';
    char    line_h = '-';
    char    line_v = '|';
    char    line_s = ' ';

    if((row==1 && col==1)||(row==1 && col==len_x)||(row==len_y && col==1)||(row==len_y && col==len_x)){
        return corner;
    }else if((col>1 && row==1 && col<len_x)||(col>1 && row==len_y && col<len_x)){
        return line_h;
    }else if((row>1 && row<len_y && col==1)||(row>1 && row<len_y && col==len_x)){
        return line_v;
    }else{
        return line_s;
    }

}